import React from 'react';

function Profile() {
    return ( 
        <main className="profile__wrapper">
            
        </main>
     );
}

export default Profile;