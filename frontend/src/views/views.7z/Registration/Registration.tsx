import React from 'react';

function Registration() {
    return ( 
        <main className="registration__wrapper">
            
        </main>
     );
}

export default Registration;