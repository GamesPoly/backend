import React from 'react';

function TeamsPage() {
    return ( 
        <main className="teams__wrapper">
            
        </main>
     );
}

export default TeamsPage;