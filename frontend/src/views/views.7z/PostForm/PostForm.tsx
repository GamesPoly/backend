import React from 'react';

function PostForm() {
    return (  
        <main className="post-form__wrapper">
            
        </main>
    );
}

export default PostForm;